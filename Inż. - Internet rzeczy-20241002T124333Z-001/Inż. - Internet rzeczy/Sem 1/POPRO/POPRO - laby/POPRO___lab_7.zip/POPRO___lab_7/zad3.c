//Lab. 7, zadanie 3
//Imię i nazwisko
//Nr albumu
//Data

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define M (4)
#define N (5)

/*
//allocates memory for a 2D array of given dimensions
//returns NULL on bad alloc or invalid user input
//no printf or scanf inside!
int* alloc2D(some_in){} 
*/

/*
//fills a 2D array of given dimensions so that array[i][j]=10*i+j;
//no printf or scanf inside!
void fill2D(some_in){} 
*/


/*
//prints a 2D array in a pretty way!
//no scanf inside!
void print2D(some_in){} 
*/

int main()
{
	int array2D_stat[M][N];
	int *array2D_dyn=NULL;

	//allocate array2D_dyn using 'alloc2D' so that it is equivallent to array2D_stat

	//fill array2D_stat using 'fill2D'

	//fill array2D_dyn using 'fill2D'
	
	//print array2D_stat using 'print2D'

	//print array2D_dyn using 'print2D'
	

	//Explain the result of 'printf'
	//Warning! Do not do such things unless you have a very good reason!
	char *h=(char*)array2D_stat;
	h[5]=2;
	printf("Element array2D_stat[0][1] is now: %d\n",array2D_stat[0][1]);

	return 0;
}
