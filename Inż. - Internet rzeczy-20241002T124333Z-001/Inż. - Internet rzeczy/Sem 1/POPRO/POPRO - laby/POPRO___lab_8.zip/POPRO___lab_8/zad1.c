#include <stdio.h>
#include <stdlib.h>

#define ROZMIAR 80

struct ElListy {
   int el;
   struct ElListy *nast;
};

typedef struct ElListy * WskElListy;
typedef enum {FALSZ, PRAWDA} Bool;

/*funkcja dodaje nowy element na poczatek listy i jako wynik zwraca wskaznik do niego*/
WskElListy dodajEl(WskElListy pierwszy, int war);
/*funcja usuwa pierwszy element dla ktorego el==war*/
WskElListy usunEl(WskElListy pierwszy, int war);
WskElListy zwolnijPam(WskElListy pierwszy);
void wyswietlListe(WskElListy pierwszy);
Bool czyPusta(WskElListy pierwszy);
void menu(WskElListy pierwszy);
char odczytMenu(void);
Bool odczytWyboru(char * tekstKom, int * wskaznikDoDanych);

int main(void) {
	WskElListy pierwszy = NULL;
	char opcja;
	int tmp;
	for(;;) {
		menu(pierwszy);
		opcja=odczytMenu();
		switch(opcja) {
			 case 'd': /*dodawanie elementu*/
				if (odczytWyboru("\nPodaj wartosc pola dana:", &tmp ))
					 pierwszy=dodajEl(pierwszy,tmp );
			    break;
			 case 'w': /*wyswietlanie elementow*/
			    wyswietlListe(pierwszy);
			    break;
			 case 'u': /*usuwanie elementu o zadanej wartosci pola: el*/
				if (odczytWyboru("\nWprowadz wartosc pola elementu do usuniecia: ", &tmp ))
					 pierwszy=usunEl(pierwszy,tmp);
				break;
			 case 'q':
				pierwszy=zwolnijPam(pierwszy);
			    exit(0);
			    break;
			 default:
			    puts("\nBledny wybor opcji menu!");
		}
	}
	return 0;
}

WskElListy dodajEl(WskElListy pierwszy, int war) {
   WskElListy nowyElListy= (WskElListy)malloc( sizeof(struct ElListy) );
   if(nowyElListy==NULL) {
      fputs("Blad alokacji pamieci",stderr);
      exit(1);
    }
   nowyElListy->el=war;
   nowyElListy->nast = pierwszy;
   return nowyElListy;
}

void wyswietlListe(WskElListy pierwszy) {
	WskElListy ElListy=pierwszy;
	unsigned licz=1;
	do {
		printf("Element %d Dane: %d\n",licz++, ElListy->el);
		ElListy = ElListy->nast;
    } while(ElListy != NULL);
}

WskElListy usunEl(WskElListy pierwszy, int war)  {
	WskElListy ElListy=pierwszy, poprzedniElListy=NULL;
	do {
        if( ElListy->el==war) {
        	if(ElListy==pierwszy) pierwszy = ElListy->nast;
        	else poprzedniElListy->nast = ElListy->nast;
        	free(ElListy);
        	return pierwszy;
        }
    	poprzedniElListy = ElListy;
        ElListy = ElListy->nast;
	} while(ElListy != NULL);
	printf("Element z polem o zadanej wartosci nie znajduje sie na liscie\n");
	return pierwszy;
}

WskElListy zwolnijPam(WskElListy pierwszy) {
   WskElListy ElListy=pierwszy, tmpWsk;
   do {
      	tmpWsk = ElListy;
     	ElListy = ElListy->nast;
      	free(tmpWsk);
    } while(ElListy != NULL);
   return NULL;
}

Bool czyPusta(WskElListy pierwszy) {
	if (pierwszy == NULL) return PRAWDA;
	else return FALSZ;
}

void menu(WskElListy pierwszy) {
	 printf("Prosze wybrać opcje:\n");
	 printf("\n\t'd'- dodanie nowego elementu do listy");
	 if (!czyPusta(pierwszy)) {
		printf("\n\t'w'- wyswietlenie wszystkich elementow listy");
		printf("\n\t'u'- usuniecie elementu z listy,");
	}
     printf("\n\t'q'- wyjscie z programu");
     printf("\n\t >");
}

char odczytMenu(void) {
	char znak, opcja[2];
	fgets(opcja,2,stdin);
	while((znak=getchar())!='\n');
	return opcja[0];
}

Bool odczytWyboru(char * tekstKom, int * wskaznikDoDanych) {
	char bufor[ROZMIAR];
	int wynikKonwersji;
	printf("%s",tekstKom);
	fgets(bufor,ROZMIAR,stdin);
	wynikKonwersji=sscanf(bufor,"%d",wskaznikDoDanych);
	if (wynikKonwersji==EOF) return FALSZ;
	else return PRAWDA;
}
